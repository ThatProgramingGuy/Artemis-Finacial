package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
class ServerController{ 
	
    private final static char[] hexArray = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for ( int j = 0; j < bytes.length; j++ ) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }
        
    public static String generateChecksum(String input) throws NoSuchAlgorithmException {
	    //create instance of message digest
	    MessageDigest md = MessageDigest.getInstance("SHA-256");
	    byte [] hash = md.digest(input.getBytes(StandardCharsets.UTF_8));
	    
            String st = bytesToHex(hash);
            return st;
    }
 
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
        String datax = "Hello David Balogun! We would love to have you use Artemis Finacial! We will work hard...";
        String outPut = generateChecksum(datax);
        
        return "<p>data:"+outPut;
    }
}
